import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-form',
  templateUrl: './course-form.component.html',
  styleUrls: ['./course-form.component.css']
})
export class CourseFormComponent {
  categories = [
    { id: 1, name: 'Development'},
    { id: 1, name: 'TimePass'},
    { id: 1, name: 'Testing'}
  ];

  onSubmit(f) {
    console.log(f);
  }
}
