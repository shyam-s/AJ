import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-zippy',
  templateUrl: './zippy.component.html',
  styleUrls: ['./zippy.component.css']
})
export class ZippyComponent {
  @Input() title: string;
  public isExpanded = false;
  @Output() opened = new EventEmitter();
  public toggle() {
    this.isExpanded = !this.isExpanded;
    if (this.isExpanded) {
      this.opened.emit(this.title);
    }
  }
}
