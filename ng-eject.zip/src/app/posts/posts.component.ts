import { AppError } from './../common/app-error';
import { PostService } from './../services/post.service';
import { Component, OnInit } from '@angular/core';
import { NotFoundError } from './../common/not-found-error';
import { BadRequestError } from './../common/bad-request-error';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {
  posts: any[];
  constructor(private service: PostService) {
  }

  addPost(input: HTMLInputElement) {
    const post = {
      title : input.value
    };

    input.value = '';

    this.service.create(post)
      .subscribe(newPost => {
        post['id'] = newPost.id;
        // this.posts.splice(0, 0, post);
        this.posts.unshift(post);
        console.log(newPost);
      },
      (error: AppError) => {
        if (error instanceof BadRequestError) {
          // this.form.setErrors(error.originalError;
        } else {
          throw error;
        }
      });
  }

  updatePost(post) {
    this.service.update(post)
      .subscribe(updatePost => {
        console.log(updatePost);
      }); // removing custom error handler
  }

  deletePost(post) {
    this.service.delete(432)
      .subscribe(() => { // delete does not return any response so empty parameter
        const index = this.posts.indexOf(post);
        this.posts.splice(index, 1);
      },
      (error: AppError) => {
        if (error instanceof NotFoundError) {
          alert('This post has already been deleted.');
        } else {
          throw error;
        }
      });
  }

  ngOnInit() {
    this.service.getAll()
      .subscribe((posts) => {
        this.posts = posts;
       }
      // error => {
      //   alert('An unexpectd error occurred');
      //   console.log(error);
      // } commenting for allowing global error handler
      );
  }

}
